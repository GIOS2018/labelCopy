//
//  AppDelegate.h
//  copyAndPasteLabel
//
//  Created by chenying on 2018/4/21.
//  Copyright © 2018年 chocolate. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

