//
//  UILabel+CopyAndPasteLable.h
//  testMacro
//
//  Created by chenying on 2018/4/17.
//  Copyright © 2018年 chocalate. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (CopyAndPasteLable)
@property(nonatomic,assign)BOOL isCopyable;
@property(nonatomic,assign)BOOL isPasteable;

@end
