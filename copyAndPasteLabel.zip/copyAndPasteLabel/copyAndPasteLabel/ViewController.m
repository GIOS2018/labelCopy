//
//  ViewController.m
//  copyAndPasteLabel
//
//  Created by chenying on 2018/4/21.
//  Copyright © 2018年 chocolate. All rights reserved.
//

#import "ViewController.h"
#import "UILabel+CopyAndPasteLable.h"
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *testCopyLabel;
;
@property (weak, nonatomic) IBOutlet UILabel *pasteLabel;
@property (weak, nonatomic) IBOutlet UILabel *testCopyAndPasteLabel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.testCopyLabel.isCopyable = YES;
    self.pasteLabel.isPasteable = YES;
    self.testCopyAndPasteLabel.isPasteable = YES;
    self.testCopyAndPasteLabel.isCopyable = YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
